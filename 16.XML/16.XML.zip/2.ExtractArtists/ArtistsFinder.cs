﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Data;

namespace _2.ExtractArtists
{
    class ArtistsFinder
    {
        const string File = @"..\..\..\Catalogue.xml";        

        static void Main()
        {
            var document = new System.Xml.XmlDocument();
            document.Load(File);

            NodeTraverse(document);

            SearchUsingXpath(document);

            var expensiveAlbums = document.SelectNodes("/albums/album/price[text() > 20.00]");

            foreach (XmlNode expensiveAlbum in expensiveAlbums)
            {
                var parent = expensiveAlbum.ParentNode;
                parent.ParentNode.RemoveChild(parent);
            }

            document.Save(File);
        }

        private static void SearchUsingXpath(XmlDocument document)
        {
            var xPathSearch = "/albums/album/artist";
            var nodes = document.SelectNodes(xPathSearch);
            foreach (XmlNode node in nodes)
            {
                Console.WriteLine(node.Value);
            }
        }

        private static void NodeTraverse(XmlDocument document)
        {

            foreach (XmlNode node in document.DocumentElement.ChildNodes)
            {
                Console.WriteLine(node["artist"].InnerText);
            }
        }
    }
}
