﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Transactions.DbConnector;
using System.Data.Entity;
using System.Data.Entity.Migrations;
using System.Data;
using Transactions.Models;
using System.Transactions;

namespace Transactions.Client
{
    public class TransactionsClient
    {
        static void Main()
        {
            // Run in PM Console : Updata-Database ( in Transactions.DbConnector ) to set unique key constraint
            // Or use TransactionsDbWithConstraints.sql provided to create DB

            // task 1
            TransactionsDAO.AddFewTestAccounts();

            // task2
            var cardnumber = "1223-321-5";
            var cash = 100;
            var pin = "1234";

            var transactionSuccessful =
                TransactionsDAO.WithdrawFromCard(cardnumber, cash, pin);

            Console.WriteLine("Transaction successful -> {0}", transactionSuccessful);           
        }        
    }
}
