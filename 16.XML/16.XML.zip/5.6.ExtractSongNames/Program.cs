﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;

namespace _5
{
    class SongsExtractor
    {
        const string File = @"..\..\..\Catalogue.xml";

        static void Main(string[] args)
        {
            Console.WriteLine("             Using xml reader");
            SongsTitlesWithReader();
            
            Console.WriteLine("\n           Using XDoc");
            SOngsTitlesWithXDoc();
        }
  
        private static void SOngsTitlesWithXDoc()
        {
            //SongsTitlesWithReader();
            XDocument doc = XDocument.Load(File);

            var songs = doc.Descendants("title").Where(x => x.Parent.Name == "song").Select(x => x.Value);

            foreach (var songTitle in songs)
            {
                Console.WriteLine(songTitle);
            }
        }
  
        private static void SongsTitlesWithReader()
        {
            var reader = System.Xml.XmlReader.Create(File);

            using (reader)
            {
                while (reader.Read())
                {
                    if (reader.Name == "song" && reader.NodeType != XmlNodeType.EndElement)
                    {
                        var next = reader.Value;
                        while (string.IsNullOrWhiteSpace(next))
                        {
                            reader.Read();
                            next = reader.Value;
                        }
                        Console.WriteLine(reader.Value.ToString());
                    }
                }
            }
        }
    }
}
