﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StudentsSystem.Context;
using StudentsSystem.Models;
using System.Data;

namespace StudentsSystem.Client
{
    public class Client
    {
        public static void Main()
        {
            using (var dbContext = new StudentSystemContext())
            { 
                //AddThreeStudents(dbContext);
                //dbContext.SaveChanges();

                //PrintOutCoursesAndStudents(dbContext);

                //AddHomeworksForGosho(dbContext);
                //dbContext.SaveChanges();

                PrintOutAllHomeworksCourses(dbContext);                
            }
        }
  
        private static void PrintOutAllHomeworksCourses(StudentSystemContext dbContext)
        {
           
            var homeworks = dbContext.Homeworks.Include("Course");
            foreach (var hw in homeworks)
            {
                Console.WriteLine("{0} -> {1}",hw.Course.Name, hw.Content);
            }
        }
  
        private static void AddHomeworksForGosho(StudentSystemContext dbContext)
        {
            
            var gosho = dbContext.Students.FirstOrDefault(s => s.Name == "gosho");

            gosho.Homeworks.Add(new Homework
            {
                TimeSent = DateTime.Now,
                Content = "Homework Content",
                CourseId = 1,
            });

            gosho.Homeworks.Add(new Homework
            {
                TimeSent = DateTime.Now,
                Content = "Homework for second lesson",
                CourseId = 1
            });
        }
  
        private static void PrintOutCoursesAndStudents(StudentSystemContext dbContext)
        {
            var courses = dbContext.Courses.Include("Students").ToList();
            foreach (var course in courses)
            {
                Console.WriteLine(course.Name);
                foreach (var student in course.Students)
                {
                    Console.WriteLine("-------------" + student.Name);
                }
            }
        }
  
        private static void AddThreeStudents(StudentSystemContext dbContext)
        {
            Console.WriteLine(dbContext.Courses.Count());
            var pesho = new Student
            {
                Name = "Pesho",
                Number = "1",
            };

            var gosho = new Student
            {
                Name = "Gosho",
                Number = "2",
            };

            var mimi = new Student
            {
                Name = "Mimi",
                Number = "3",
            };

            dbContext.Students.Add(pesho);
            dbContext.Students.Add(gosho);
            dbContext.Students.Add(mimi);

            var cSharpOne = new Course
            {
                Name = "C# part 1",
            };

            cSharpOne.Students.Add(pesho);
            cSharpOne.Students.Add(gosho);
            cSharpOne.Students.Add(mimi);

            dbContext.Courses.Add(cSharpOne);          
        }

    }
}
