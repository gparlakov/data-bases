﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelerikAcademy.PerformaceChecks
{
    class Performace
    {
        static void Main(string[] args)
        {
            using (var telerikAcademyDb = new TelerikAcademyDb())
            {
                //1 task
                EmployeesTest(telerikAcademyDb);

                //2.task
                ToListAfterEachQuery(telerikAcademyDb);

                FasterAndSmaller(telerikAcademyDb);
            }
        }
  
        private static void FasterAndSmaller(TelerikAcademyDb telerikAcademyDb)
        {
            var employeesWithout = telerikAcademyDb.Employees
                .Join(telerikAcademyDb.Addresses, e => e.AddressID, a => a.AddressID, (e, a) => new
                {
                    EmployeeName = e.LastName,
                    TownId = a.TownID
                })
                .Join(telerikAcademyDb.Towns, a => a.TownId, t => t.TownID, (a, t) => new
                {
                    TownName = t.Name,
                    EmployeeName = a.EmployeeName
                })
                .Where(t => t.TownName == "Sofia");
            Console.WriteLine(employeesWithout.First().TownName);
        }
  
        private static void ToListAfterEachQuery(TelerikAcademyDb telerikAcademyDb)
        {          
            var employees = telerikAcademyDb.Employees
                .ToList()
                .Join(telerikAcademyDb.Addresses, e => e.AddressID, a => a.AddressID, (e,a) => new
                {
                    EmployeeName = e.LastName,
                    TownId = a.TownID
                })
                .ToList()
                .Join(telerikAcademyDb.Towns, a => a.TownId, t => t.TownID, (a,t) => new
                {
                    TownName = t.Name,
                    EmployeeName = a.EmployeeName
                })
                .ToList()
                .Where(t => t.TownName == "Sofia");
        }
  
        private static void EmployeesTest(TelerikAcademyDb telerikAcademyDb)
        {
            var employees = telerikAcademyDb.Employees;
            foreach (var employee in employees)
            {
                Console.WriteLine("Name: {0}| department: {1}| Town {2}",
                    employee.LastName, employee.Department.Name, employee.Address.Town.Name);
            }

            var employeesIncluded = telerikAcademyDb.Employees.Include("Department").Include("Address.Town");
            foreach (var employee in employeesIncluded)
            {
                Console.WriteLine("Name: {0}| department: {1}| Town {2}",
                    employee.LastName, employee.Department.Name, employee.Address.Town.Name);
            }
        }
    }
}
