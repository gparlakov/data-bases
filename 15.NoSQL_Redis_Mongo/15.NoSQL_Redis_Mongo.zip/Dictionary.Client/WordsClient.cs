﻿using Dictionary.Models;
using Dictionary.MongoDbPersister;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Dictionary.Client
{
    class WordsClient
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Works with local mongo!");

            AddOrUpdate("Word", "Дума");
            AddOrUpdate("Dictinary", "Ре4ник");
            AddOrUpdate("Word", "Дума");
            AddOrUpdate("Dictinary", "Речник");
            AddOrUpdate("keyboard", "Клавиатура");

            PrintAllWords();

            FindTranslation("Word");
        }

        private static void FindTranslation(string word)
        {
            var translation = MongoDbContext.GetTranslation(word);
            Console.WriteLine(translation);
        }

        private static void PrintAllWords()
        {
            var words = MongoDbContext.ListAllWords();

            Thread.CurrentThread.CurrentCulture = new CultureInfo("bg-BG");

            using (var writer = new StreamWriter(@"..\..\words.txt"))
            {
                foreach (var word in words)
                {
                    writer.WriteLine(word.Name + " = " + word.Translation.ToString());
                }
            }

            Console.WriteLine(@"All words in file ..\..\words.txt");
        }

        private static void AddOrUpdate(string name, string Translation)
        {
            MongoDbContext.AddOrUpdateWord(
                new Word 
                { 
                    Name = name, 
                    Translation = Translation 
                });
        }
    }
}
