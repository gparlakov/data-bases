﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1.CreateXML
{
    public class Song
    {
        public string Title { get; set; }
        public string Duration { get; set; }
    }
}
