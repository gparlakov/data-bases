﻿using System.Data.Entity;
using Transactions.Models;

namespace Transactions.DbConnector
{
    public class TransactionsDb : System.Data.Entity.DbContext
    {
        public TransactionsDb()
            :base("TransactionsDb")
        {
        }

       public DbSet<CardAccount> CardAccounts { get; set; }
       public DbSet<TransactionHistory> TransactionHistory { get; set; }
    }
}
