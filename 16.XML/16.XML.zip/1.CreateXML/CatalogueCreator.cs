﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace _1.CreateXML
{
    class CatalogueCreator
    {
        const string File = @"..\..\..\Catalogue.xml";

        static void Main(string[] args)
        {
            var michaelsAlbum = new Album
            {
                Name = "TheBest",
                Artist = "Michael Jackson",
                Year = "1995",
                Producer = "producers from the block...",
                Price = "19.95",
                Songs = new List<Song> 
                {
                    new Song
                    {
                        Title = "Thriller",
                        Duration = "4.07"
                    },
                    new Song
                    {
                        Title = "SecondSong",
                        Duration = "3.18"
                    },
                    new Song
                    {
                        Title = "Thriller 23",
                        Duration = "3.56"
                    },
                    new Song
                    {
                        Title = "Thriller 34",
                        Duration = "4.07"
                    }
                }
            };

            var slavisAlbum = new Album
            {
                Name = "TheBest",
                Artist = "Slavi Trifonov",
                Year = "2013",
                Producer = "TriVodiSofiq",
                Price = "29.95",
                Songs = new List<Song> 
                {
                    new Song
                    {
                        Title = "Slavi",
                        Duration = "4.07"
                    },
                    new Song
                    {
                        Title = "Godji",
                        Duration = "3.18"
                    },
                    new Song
                    {
                        Title = "Toq",
                        Duration = "3.56"
                    },
                    new Song
                    {
                        Title = "Onq",
                        Duration = "4.07"
                    },
                    new Song
                    {
                        Title = "IDvamataOtPernik",
                        Duration = "4.07"
                    }
                }
            };

            var encoding = Encoding.GetEncoding("windows-1251");

            using (var writer = new XmlTextWriter(File, encoding))
            {
                writer.Formatting = Formatting.Indented;
                writer.Indentation = 1;
                writer.IndentChar = '\t';

                writer.WriteStartDocument();
                writer.WriteStartElement("albums");

                AddAlbum(michaelsAlbum, writer);

                AddAlbum(slavisAlbum, writer);


                writer.WriteEndElement();
                writer.WriteEndDocument(); 
            }
        }

        private static void AddAlbum(Album album, XmlTextWriter writer)
        {
            writer.WriteStartElement("album");
            writer.WriteElementString("name", album.Name);
            writer.WriteElementString("artist", album.Artist);
            writer.WriteElementString("year", album.Year);
            writer.WriteElementString("producer", album.Producer);
            writer.WriteElementString("price", album.Price);

            writer.WriteStartElement("songs");

            AddSongs(album, writer);
            writer.WriteEndElement();

            writer.WriteEndElement();
        }

        private static void AddSongs(Album album, XmlTextWriter writer)
        {
            foreach (var song in album.Songs)
            {
                writer.WriteStartElement("song");
                writer.WriteElementString("title", song.Title);
                writer.WriteElementString("duration", song.Duration);
                writer.WriteEndElement();
            }
        }
    }
}
