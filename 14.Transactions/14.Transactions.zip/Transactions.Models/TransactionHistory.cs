﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Transactions.Models
{
    [Table(name:"TransactionLog")]
    public class TransactionHistory
    {
        public int Id { get; set; }

        public string CardNumber { get; set; }

        public decimal Ammount { get; set; }

        public DateTime TransactionDate { get; set; }
    }
}
