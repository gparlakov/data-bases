﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SimpleSearch
{
    public class SimpleSearchResult
    {
        public string Title { get; set; }

        public int ReviewsCount { get; set; }
    }
}
