namespace StudentsSystem.Context.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using StudentsSystem.Models;
    using System.Collections.Generic;

    internal sealed class Configuration : 
        DbMigrationsConfiguration<StudentsSystem.Context.StudentSystemContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
            AutomaticMigrationDataLossAllowed = true;
        }

        protected override void Seed(StudentsSystem.Context.StudentSystemContext context)
        {
            //task 3
            context.Students.AddOrUpdate(s => s.Name,
                new Student
                {
                    Name = "Pesho",
                    Number = "1",                   
                },
                new Student
                {
                    Name = "Gosho",
                    Number = "2",
                },
                new Student
                {
                    Name = "Mimi",
                    Number = "3",
                });

            context.Courses.AddOrUpdate(c => c.Name,
                new Course
                {
                    Name = "C# Part I",
                    Description = "Basic Knowledge of C# and programming Part I"
                },
                new Course
                {
                    Name = "C# Part II",
                    Description = "Basic Knowledge of C# and programming Part II"
                },
                new Course
                {
                    Name = "HTML",
                    Description = "Basic Knowledge of HTML"
                },
                new Course
                {
                    Name = "JavaScript",
                    Description = "Basic Knowledge of JavaScript"
                });


            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data. E.g.
            //
            //    context.People.AddOrUpdate(
            //      p => p.FullName,
            //      new Person { FullName = "Andrew Peters" },
            //      new Person { FullName = "Brice Lambson" },
            //      new Person { FullName = "Rowan Miller" }
            //    );
            //

        
        }
    }
}
