﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MongoDB.Driver;
using MongoDB.Driver.Linq;
using Dictionary.Models;
using System.Data;

namespace Dictionary.MongoDbPersister
{
    public static class MongoDbContext
    {
        const string Connection = "mongodb://localhost";
        const string WordsCollection = "CollectionWords";
        const string WordsDatabase = "WordsDb"; 

        public static MongoClient DbContext 
        {
            get
            {
                return new MongoDB.Driver.MongoClient(Connection);
            }
        }

        public static void AddOrUpdateWord(Word newWord)
        {
            var words = DbContext.GetServer().GetDatabase(WordsDatabase)
                .GetCollection<Word>(WordsCollection);

            var addedWord = words.AsQueryable().Where(w => w.Name == newWord.Name).FirstOrDefault();
            if (addedWord != null)
            {
                addedWord.Translation = newWord.Translation;
                words.Save<Word>(addedWord);
            }
            else
            {
                words.Insert<Word>(newWord);
            }
        }

        public static IList<Word> ListAllWords()
        {
            var words = DbContext.GetServer().GetDatabase(WordsDatabase)
                .GetCollection<Word>(WordsCollection).AsQueryable().ToList();
            
            return words;
        }


        public static string GetTranslation(string word)
        {
            var words = DbContext.GetServer().GetDatabase(WordsDatabase)
                .GetCollection<Word>(WordsCollection).AsQueryable();

           var translation = words.Where(w => w.Name == word).Select(x => x.Translation).FirstOrDefault();
           if (translation == null)
           {
               return "Not found";
           }

           return translation;
        }
    }
}
