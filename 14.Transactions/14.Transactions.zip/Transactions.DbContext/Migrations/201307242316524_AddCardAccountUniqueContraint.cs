namespace Transactions.DbContext.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class AddCardAccountUniqueContraint : DbMigration
    {
        public override void Up()
        {
            Sql(@"                
                ALTER TABLE CardAccounts
                ADD CONSTRAINT UK_UniqueCardNumber UNIQUE (CardNumber)");
        }
        
        public override void Down()
        {
            Sql(@"
                ALTER TABLE CardAccounts
                DROP CONSTRAINT UK_UniqueCardNumber");
        }
    }
}
