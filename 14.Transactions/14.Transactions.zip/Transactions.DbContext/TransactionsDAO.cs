﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.Data.Entity.Migrations;
using System.Data;
using Transactions.Models;
using System.Transactions;
using Transactions.DbConnector;

namespace Transactions.DbConnector
{
    public static class TransactionsDAO
    {
        public static void AddTransactionInHistory(string cardnumber, int cash, TransactionsDb context)
        {
            var newLogEntry = new TransactionHistory
            {
                CardNumber = cardnumber,
                Ammount = -cash,
                TransactionDate = DateTime.Now
            };

            context.TransactionHistory.AddOrUpdate(newLogEntry);
        }

        public static bool WithdrawFromCard(string cardnumber, int cash, string cardPin)
        {
            var transactionSuccessful = false;

            var transaction = new TransactionScope(TransactionScopeOption.Required,
                new TransactionOptions
                {
                    IsolationLevel = System.Transactions.IsolationLevel.RepeatableRead
                });

            using (transaction)
            {
                var context = new Transactions.DbConnector.TransactionsDb();
                var card = context.CardAccounts
                    .Where(c => c.CardNumber == cardnumber && c.CardPin == cardPin).FirstOrDefault();

                if (card != null && card.CardCash >= cash)
                {
                    card.CardCash -= cash;

                    transactionSuccessful = true;

                    AddTransactionInHistory(cardnumber, cash, context);

                    context.SaveChanges();

                    transaction.Complete();
                }
            }

            return transactionSuccessful;
        }

        public static void AddFewTestAccounts()
        {
            using (var transDb = new TransactionsDb())
            {
                transDb.CardAccounts.Add(new CardAccount { CardCash = 1000m, CardNumber = "1223-321-1", CardPin = "1234" });
                transDb.CardAccounts.Add(new CardAccount { CardCash = 1000m, CardNumber = "1223-321-2", CardPin = "0000" });
                transDb.CardAccounts.Add(new CardAccount { CardCash = 1000m, CardNumber = "1223-321-3", CardPin = "0000" });
                transDb.CardAccounts.Add(new CardAccount { CardCash = 1000m, CardNumber = "1223-321-4", CardPin = "4321" });
                transDb.CardAccounts.Add(new CardAccount { CardCash = 1000m, CardNumber = "1223-321-5", CardPin = "1234" });
                transDb.CardAccounts.Add(new CardAccount { CardCash = 1000m, CardNumber = "1223-321-6", CardPin = "1462" });
                transDb.CardAccounts.Add(new CardAccount { CardCash = 1000m, CardNumber = "1223-321-7", CardPin = "4311" });
                transDb.CardAccounts.Add(new CardAccount { CardCash = 1000m, CardNumber = "1223-321-8", CardPin = "4421" });
                transDb.SaveChanges();
            }
        }
    }
}
