﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Transactions.Models
{
    public class CardAccount
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }
           
        [StringLength(10, MinimumLength=10, ErrorMessage="Card number is 10 symbols exactly")]        
        public string CardNumber { get; set; }

        [StringLength(4,MinimumLength=4, ErrorMessage="CardPIN is exactly 4 symbols exactly")]
        public string CardPin { get; set; }

        
        public decimal CardCash { get; set; }
    }
}
